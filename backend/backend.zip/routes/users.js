const express = require("express");
const router = express.Router();
const mysql = require("mysql2");

const pool = mysql.createPool({
    host: "217.21.94.52",
    user: "u210346953_forum",
    password: "Forum@1234",
    database: "u210346953_forum",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

router.post("/login", async (req, res) => {
    try {
        const { email, displayName, photoURL } = req.body;
        const query = `SELECT * FROM users WHERE email = ?`;
        
        pool.query(query, [email], (err, result) => {
            if (err) {
                console.error("Error from users.js", err);
                return res.status(400).json({ "code": 0, message: "Login failed" });
            }
            
            if (result.length === 0) {
                const insertQuery = `INSERT INTO users (email, displayName, photoURL) VALUES (?, ?, ?)`;
                pool.query(insertQuery, [email, displayName, photoURL], (err, insertResult) => {
                    if (err) {
                        console.error("Error from users.js", err);
                        return res.status(400).json({ "code": 0, message: "User creation failed" });
                    }
                    res.status(201).json({ "code": 1, message: "User created successfully" });
                });
            } else {
                res.status(200).json({ "code": 1, message: "Login successful", data: result[0] });
            }
        });
    } catch (e) {
        console.error("Error from users.js", e);
        res.status(400).json({ "code": 0, message: "Login failed" });
    }
});

router.post('/follow', async (req, res) => {
    try {
        const { follower, following } = req.body;
        const query = `INSERT INTO follow (follower, following) VALUES (?, ?)`;
        
        pool.query(query, [follower, following], (err, result) => {
            if (err) {
                console.error("Error from users.js", err);
                return res.status(400).json({ "code": 0, message: "Follow failed" });
            }
            res.status(201).json({ "code": 1, message: "Followed successfully" });
        });
    } catch (e) {
        console.error("Error from users.js", e);
        res.status(400).json({ "code": 0, message: "Follow failed" });
    }
});

module.exports = router;
